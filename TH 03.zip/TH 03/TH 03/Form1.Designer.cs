﻿namespace TH_03
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_un = new System.Windows.Forms.TextBox();
            this.tb_pw = new System.Windows.Forms.TextBox();
            this.b_login = new System.Windows.Forms.Button();
            this.b_regis = new System.Windows.Forms.Button();
            this.panelregis = new System.Windows.Forms.Panel();
            this.buttonregis = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tb2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tb1 = new System.Windows.Forms.TextBox();
            this.panellogin = new System.Windows.Forms.Panel();
            this.button_withdraw = new System.Windows.Forms.Button();
            this.button_deposit = new System.Windows.Forms.Button();
            this.button_logout = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel_atm = new System.Windows.Forms.Panel();
            this.balance = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tb_deposit = new System.Windows.Forms.TextBox();
            this.bdepos = new System.Windows.Forms.Button();
            this.logoutdeposit = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.paneldeposit = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.wd = new System.Windows.Forms.Label();
            this.logout = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.tb_withdraw = new System.Windows.Forms.TextBox();
            this.butt_withdraw = new System.Windows.Forms.Button();
            this.panel_wd = new System.Windows.Forms.Panel();
            this.panelregis.SuspendLayout();
            this.panellogin.SuspendLayout();
            this.panel_atm.SuspendLayout();
            this.paneldeposit.SuspendLayout();
            this.panel_wd.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(86, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(186, 38);
            this.label1.TabIndex = 0;
            this.label1.Text = "UC BANK";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("NSimSun", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 27);
            this.label2.TabIndex = 1;
            this.label2.Text = "Username:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("NSimSun", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(1, 147);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(147, 27);
            this.label3.TabIndex = 2;
            this.label3.Text = "Password:";
            // 
            // tb_un
            // 
            this.tb_un.Location = new System.Drawing.Point(154, 90);
            this.tb_un.Name = "tb_un";
            this.tb_un.Size = new System.Drawing.Size(186, 31);
            this.tb_un.TabIndex = 3;
            // 
            // tb_pw
            // 
            this.tb_pw.Location = new System.Drawing.Point(154, 143);
            this.tb_pw.Name = "tb_pw";
            this.tb_pw.Size = new System.Drawing.Size(186, 31);
            this.tb_pw.TabIndex = 4;
            // 
            // b_login
            // 
            this.b_login.Font = new System.Drawing.Font("Segoe Print", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_login.Location = new System.Drawing.Point(106, 205);
            this.b_login.Name = "b_login";
            this.b_login.Size = new System.Drawing.Size(131, 52);
            this.b_login.TabIndex = 5;
            this.b_login.Text = "Login";
            this.b_login.UseVisualStyleBackColor = true;
            this.b_login.Click += new System.EventHandler(this.b_login_Click);
            // 
            // b_regis
            // 
            this.b_regis.Font = new System.Drawing.Font("Segoe Print", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_regis.Location = new System.Drawing.Point(106, 273);
            this.b_regis.Name = "b_regis";
            this.b_regis.Size = new System.Drawing.Size(131, 54);
            this.b_regis.TabIndex = 7;
            this.b_regis.Text = "Register";
            this.b_regis.UseVisualStyleBackColor = true;
            this.b_regis.Click += new System.EventHandler(this.b_regis_Click);
            // 
            // panelregis
            // 
            this.panelregis.Controls.Add(this.buttonregis);
            this.panelregis.Controls.Add(this.label6);
            this.panelregis.Controls.Add(this.label5);
            this.panelregis.Controls.Add(this.tb2);
            this.panelregis.Controls.Add(this.label4);
            this.panelregis.Controls.Add(this.tb1);
            this.panelregis.Location = new System.Drawing.Point(662, 59);
            this.panelregis.Name = "panelregis";
            this.panelregis.Size = new System.Drawing.Size(370, 274);
            this.panelregis.TabIndex = 8;
            this.panelregis.Visible = false;
            // 
            // buttonregis
            // 
            this.buttonregis.Font = new System.Drawing.Font("Segoe Print", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonregis.Location = new System.Drawing.Point(106, 208);
            this.buttonregis.Name = "buttonregis";
            this.buttonregis.Size = new System.Drawing.Size(131, 54);
            this.buttonregis.TabIndex = 15;
            this.buttonregis.Text = "Register";
            this.buttonregis.UseVisualStyleBackColor = true;
            this.buttonregis.Click += new System.EventHandler(this.buttonregis_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Modern No. 20", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(99, 15);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(186, 38);
            this.label6.TabIndex = 9;
            this.label6.Text = "UC BANK";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("NSimSun", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(14, 99);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(147, 27);
            this.label5.TabIndex = 10;
            this.label5.Text = "Username:";
            // 
            // tb2
            // 
            this.tb2.Location = new System.Drawing.Point(167, 152);
            this.tb2.Name = "tb2";
            this.tb2.Size = new System.Drawing.Size(186, 31);
            this.tb2.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("NSimSun", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(14, 156);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(147, 27);
            this.label4.TabIndex = 11;
            this.label4.Text = "Password:";
            // 
            // tb1
            // 
            this.tb1.Location = new System.Drawing.Point(167, 99);
            this.tb1.Name = "tb1";
            this.tb1.Size = new System.Drawing.Size(186, 31);
            this.tb1.TabIndex = 12;
            // 
            // panellogin
            // 
            this.panellogin.Controls.Add(this.b_regis);
            this.panellogin.Controls.Add(this.b_login);
            this.panellogin.Controls.Add(this.tb_pw);
            this.panellogin.Controls.Add(this.tb_un);
            this.panellogin.Controls.Add(this.label3);
            this.panellogin.Controls.Add(this.label2);
            this.panellogin.Controls.Add(this.label1);
            this.panellogin.Location = new System.Drawing.Point(131, 59);
            this.panellogin.Name = "panellogin";
            this.panellogin.Size = new System.Drawing.Size(348, 339);
            this.panellogin.TabIndex = 9;
            // 
            // button_withdraw
            // 
            this.button_withdraw.Font = new System.Drawing.Font("Segoe Print", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_withdraw.Location = new System.Drawing.Point(108, 282);
            this.button_withdraw.Name = "button_withdraw";
            this.button_withdraw.Size = new System.Drawing.Size(131, 52);
            this.button_withdraw.TabIndex = 8;
            this.button_withdraw.Text = "Withdraw";
            this.button_withdraw.UseVisualStyleBackColor = true;
            this.button_withdraw.Click += new System.EventHandler(this.button_withdraw_Click);
            // 
            // button_deposit
            // 
            this.button_deposit.Font = new System.Drawing.Font("Segoe Print", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_deposit.Location = new System.Drawing.Point(108, 208);
            this.button_deposit.Name = "button_deposit";
            this.button_deposit.Size = new System.Drawing.Size(131, 52);
            this.button_deposit.TabIndex = 9;
            this.button_deposit.Text = "Deposit";
            this.button_deposit.UseVisualStyleBackColor = true;
            this.button_deposit.Click += new System.EventHandler(this.button_deposit_Click);
            // 
            // button_logout
            // 
            this.button_logout.Font = new System.Drawing.Font("Segoe Print", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_logout.Location = new System.Drawing.Point(275, 45);
            this.button_logout.Name = "button_logout";
            this.button_logout.Size = new System.Drawing.Size(131, 52);
            this.button_logout.TabIndex = 10;
            this.button_logout.Text = "Log Out";
            this.button_logout.UseVisualStyleBackColor = true;
            this.button_logout.Click += new System.EventHandler(this.button_logout_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("NSimSun", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(36, 141);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(117, 27);
            this.label7.TabIndex = 8;
            this.label7.Text = "Balance";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Modern No. 20", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(10, 21);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(186, 38);
            this.label8.TabIndex = 16;
            this.label8.Text = "UC BANK";
            // 
            // panel_atm
            // 
            this.panel_atm.Controls.Add(this.balance);
            this.panel_atm.Controls.Add(this.button_logout);
            this.panel_atm.Controls.Add(this.button_deposit);
            this.panel_atm.Controls.Add(this.label8);
            this.panel_atm.Controls.Add(this.button_withdraw);
            this.panel_atm.Controls.Add(this.label7);
            this.panel_atm.Location = new System.Drawing.Point(73, 466);
            this.panel_atm.Name = "panel_atm";
            this.panel_atm.Size = new System.Drawing.Size(422, 352);
            this.panel_atm.TabIndex = 17;
            this.panel_atm.Visible = false;
            // 
            // balance
            // 
            this.balance.AutoSize = true;
            this.balance.Font = new System.Drawing.Font("NSimSun", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.balance.Location = new System.Drawing.Point(175, 141);
            this.balance.Name = "balance";
            this.balance.Size = new System.Drawing.Size(27, 27);
            this.balance.TabIndex = 18;
            this.balance.Text = "R";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("NSimSun", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(9, 109);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(312, 27);
            this.label9.TabIndex = 19;
            this.label9.Text = "Input Deposit Amount";
            // 
            // tb_deposit
            // 
            this.tb_deposit.Location = new System.Drawing.Point(78, 165);
            this.tb_deposit.Name = "tb_deposit";
            this.tb_deposit.Size = new System.Drawing.Size(186, 31);
            this.tb_deposit.TabIndex = 8;
            // 
            // bdepos
            // 
            this.bdepos.Font = new System.Drawing.Font("Segoe Print", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bdepos.Location = new System.Drawing.Point(101, 226);
            this.bdepos.Name = "bdepos";
            this.bdepos.Size = new System.Drawing.Size(131, 52);
            this.bdepos.TabIndex = 19;
            this.bdepos.Text = "Deposit";
            this.bdepos.UseVisualStyleBackColor = true;
            this.bdepos.Click += new System.EventHandler(this.bdepos_Click);
            // 
            // logoutdeposit
            // 
            this.logoutdeposit.Font = new System.Drawing.Font("Segoe Print", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoutdeposit.Location = new System.Drawing.Point(217, 29);
            this.logoutdeposit.Name = "logoutdeposit";
            this.logoutdeposit.Size = new System.Drawing.Size(131, 52);
            this.logoutdeposit.TabIndex = 19;
            this.logoutdeposit.Text = "Log Out";
            this.logoutdeposit.UseVisualStyleBackColor = true;
            this.logoutdeposit.Click += new System.EventHandler(this.logoutdeposit_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Modern No. 20", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(23, 12);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(186, 38);
            this.label10.TabIndex = 19;
            this.label10.Text = "UC BANK";
            // 
            // paneldeposit
            // 
            this.paneldeposit.Controls.Add(this.logoutdeposit);
            this.paneldeposit.Controls.Add(this.label10);
            this.paneldeposit.Controls.Add(this.bdepos);
            this.paneldeposit.Controls.Add(this.tb_deposit);
            this.paneldeposit.Controls.Add(this.label9);
            this.paneldeposit.Location = new System.Drawing.Point(651, 466);
            this.paneldeposit.Name = "paneldeposit";
            this.paneldeposit.Size = new System.Drawing.Size(364, 307);
            this.paneldeposit.TabIndex = 20;
            this.paneldeposit.Visible = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("NSimSun", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(7, 142);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(357, 27);
            this.label11.TabIndex = 20;
            this.label11.Text = "Input Withdrawal Amount";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("NSimSun", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(65, 91);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(117, 27);
            this.label12.TabIndex = 19;
            this.label12.Text = "Balance";
            // 
            // wd
            // 
            this.wd.AutoSize = true;
            this.wd.Font = new System.Drawing.Font("NSimSun", 10.125F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wd.Location = new System.Drawing.Point(215, 91);
            this.wd.Name = "wd";
            this.wd.Size = new System.Drawing.Size(117, 27);
            this.wd.TabIndex = 19;
            this.wd.Text = "Rp 0,00";
            // 
            // logout
            // 
            this.logout.Font = new System.Drawing.Font("Segoe Print", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logout.Location = new System.Drawing.Point(296, 28);
            this.logout.Name = "logout";
            this.logout.Size = new System.Drawing.Size(131, 52);
            this.logout.TabIndex = 20;
            this.logout.Text = "Log Out";
            this.logout.UseVisualStyleBackColor = true;
            this.logout.Click += new System.EventHandler(this.logout_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Modern No. 20", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(63, 4);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(186, 38);
            this.label14.TabIndex = 20;
            this.label14.Text = "UC BANK";
            // 
            // tb_withdraw
            // 
            this.tb_withdraw.Location = new System.Drawing.Point(104, 197);
            this.tb_withdraw.Name = "tb_withdraw";
            this.tb_withdraw.Size = new System.Drawing.Size(186, 31);
            this.tb_withdraw.TabIndex = 20;
            // 
            // butt_withdraw
            // 
            this.butt_withdraw.Font = new System.Drawing.Font("Segoe Print", 7.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butt_withdraw.Location = new System.Drawing.Point(129, 247);
            this.butt_withdraw.Name = "butt_withdraw";
            this.butt_withdraw.Size = new System.Drawing.Size(131, 52);
            this.butt_withdraw.TabIndex = 19;
            this.butt_withdraw.Text = "Withdraw";
            this.butt_withdraw.UseVisualStyleBackColor = true;
            this.butt_withdraw.Click += new System.EventHandler(this.butt_withdraw_Click);
            // 
            // panel_wd
            // 
            this.panel_wd.Controls.Add(this.butt_withdraw);
            this.panel_wd.Controls.Add(this.tb_withdraw);
            this.panel_wd.Controls.Add(this.label14);
            this.panel_wd.Controls.Add(this.logout);
            this.panel_wd.Controls.Add(this.wd);
            this.panel_wd.Controls.Add(this.label12);
            this.panel_wd.Controls.Add(this.label11);
            this.panel_wd.Location = new System.Drawing.Point(1114, 445);
            this.panel_wd.Name = "panel_wd";
            this.panel_wd.Size = new System.Drawing.Size(438, 303);
            this.panel_wd.TabIndex = 21;
            this.panel_wd.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1657, 895);
            this.Controls.Add(this.panel_wd);
            this.Controls.Add(this.paneldeposit);
            this.Controls.Add(this.panel_atm);
            this.Controls.Add(this.panellogin);
            this.Controls.Add(this.panelregis);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panelregis.ResumeLayout(false);
            this.panelregis.PerformLayout();
            this.panellogin.ResumeLayout(false);
            this.panellogin.PerformLayout();
            this.panel_atm.ResumeLayout(false);
            this.panel_atm.PerformLayout();
            this.paneldeposit.ResumeLayout(false);
            this.paneldeposit.PerformLayout();
            this.panel_wd.ResumeLayout(false);
            this.panel_wd.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_un;
        private System.Windows.Forms.TextBox tb_pw;
        private System.Windows.Forms.Button b_login;
        private System.Windows.Forms.Button b_regis;
        private System.Windows.Forms.Panel panelregis;
        private System.Windows.Forms.Button buttonregis;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb1;
        private System.Windows.Forms.Panel panellogin;
        private System.Windows.Forms.Button button_withdraw;
        private System.Windows.Forms.Button button_deposit;
        private System.Windows.Forms.Button button_logout;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel_atm;
        private System.Windows.Forms.Label balance;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tb_deposit;
        private System.Windows.Forms.Button bdepos;
        private System.Windows.Forms.Button logoutdeposit;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel paneldeposit;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label wd;
        private System.Windows.Forms.Button logout;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tb_withdraw;
        private System.Windows.Forms.Button butt_withdraw;
        private System.Windows.Forms.Panel panel_wd;
    }
}

