﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH_03
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        DataTable dtUser = new DataTable();
        bool a = false;
        int bal;
        private void b_regis_Click(object sender, EventArgs e)
        {
            panellogin.Visible = false;
            panelregis.Visible = true;
            panelregis.Top = 31;
            panelregis.Left = 66;
        }

        private void buttonregis_Click(object sender, EventArgs e)
        {
            tb_un.Text = "";
            tb_pw.Text = "";
            int tes = 0;
            if (dtUser.Rows.Count != 0)
            {
                for (int i = 0; i < dtUser.Rows.Count; i++)
                {
                    if (tb1.Text == dtUser.Rows[i][0].ToString() && tes == i)
                    {
                        MessageBox.Show("Username has been used");
                        tb1.Text = "";
                        tb2.Text = "";
                        break;
                    }
                    else
                    {
                        if (tes == dtUser.Rows.Count - 1)
                        {
                            MessageBox.Show("Register Successful");
                            panellogin.Visible = true;
                            panelregis.Visible = false;
                            dtUser.Rows.Add(tb1.Text, tb2.Text, 0);
                            tb1.Text = "";
                            tb2.Text = "";
                            break;
                        }
                        tes++;
                    }
                }
            }
            else
            {
                MessageBox.Show("Register Successful");
                panellogin.Visible = true;
                panelregis.Visible = false;
                dtUser.Rows.Add(tb1.Text, tb2.Text, 0);
                tb1.Text = "";
                tb2.Text = "";
            }
        }

        private void b_login_Click(object sender, EventArgs e)
        {
            int tes = 0;
            if (dtUser.Rows.Count != 0)
            {
                for (int i = 0; i < dtUser.Rows.Count; i++)
                {
                    if (tb_un.Text == dtUser.Rows[i][0].ToString() && tb_pw.Text == dtUser.Rows[i][1].ToString())
                    {
                        MessageBox.Show("Login Successful");
                        bal = i;
                        a = true;
                        break;
                    }
                    else 
                    {
                        if (i == dtUser.Rows.Count - 1)
                        {
                            MessageBox.Show("Username and Password not Found!");
                        }
                        tes++;
                    }
                }
                tb_un.Text = "";
                tb_pw.Text = "";
            }
            else
            {
                MessageBox.Show("Username and Password not Found!");
            }

            tb_un.Text = "";
            tb_pw.Text = "";

            if (a == true)
            {
                panel_atm.Visible = true;
                panellogin.Visible = false;
                panel_atm.Top = 31;
                panel_atm.Left = 66;
                balance.Text = "Rp " + Convert.ToInt32(dtUser.Rows[bal][2]).ToString("C2").Remove(0, 1);
                a = false;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dtUser.Columns.Add("Username");
            dtUser.Columns.Add("Password");
            dtUser.Columns.Add("Uang");
        }
        private void logout_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Log Out Berhasil");
            panel_wd.Visible = false;
            panellogin.Visible = true;
        }
        private void button_logout_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Log Out Berhasil");
            panel_atm.Visible = false;
            panellogin.Visible = true;
        }

        private void logoutdeposit_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Log Out Berhasil");
            paneldeposit.Visible = false;
            panellogin.Visible = true;
        }

        private void button_deposit_Click(object sender, EventArgs e)
        {
            paneldeposit.Visible = true;
            panel_atm.Visible = false;
            paneldeposit.Top = 31;
            paneldeposit.Left = 66;
        }

        private void button_withdraw_Click(object sender, EventArgs e)
        {
            panel_wd.Visible = true;
            panel_atm.Visible = false;
            panel_wd.Top = 31;
            panel_wd.Left = 66;
            wd.Text = balance.Text;
        }

        private void bdepos_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt64(tb_deposit.Text) > 0)
            {
                int depo = Convert.ToInt32(tb_deposit.Text);
                int tot = Convert.ToInt32(dtUser.Rows[bal][2].ToString());
                int total = depo + tot;
                balance.Text = "Rp" + total.ToString("C2").Remove(0, 1);
                dtUser.Rows[bal][2] = total;
                MessageBox.Show("Succesfully Add Deposit");
                panel_atm.Visible = true;
                paneldeposit.Visible = false;
                tb_deposit.Text = "";
            }
            else
            {
                MessageBox.Show("Deposit Amount Can't Be Less Than 1");
                tb_deposit.Text = "";
                panel_atm.Visible = true;
                paneldeposit.Visible = false;
            }
        }

        
        private void butt_withdraw_Click(object sender, EventArgs e)
        {
            int depo = Convert.ToInt32(tb_withdraw.Text);
            int uang = Convert.ToInt32(dtUser.Rows[bal][2].ToString());
            wd.Text = balance.Text;
            if (depo <= uang && depo > 0)
            {
                int total = uang - depo;
                balance.Text = "Rp" + total.ToString("C2").Remove(0, 1);
                MessageBox.Show("Succesfully Withdraw");
                dtUser.Rows[bal][2] = total;
                tb_withdraw.Text = "";
                panel_atm.Visible = true;
                panel_wd.Visible = false;
            }
            else if (depo > uang)
            {
                MessageBox.Show("Withdraw Failed. Not Enough Balance.");
                tb_withdraw.Text = "";
                panel_atm.Visible = true;
                panel_wd.Visible = false;
            }
            else
            {
                MessageBox.Show("Withdraw Amount Can't Be Less Than 1");
                tb_withdraw.Text = "";
                panel_atm.Visible = true;
                panel_wd.Visible = false;
            }
        }
    }
}
